module Peatio
  module Tron
    VERSION = "0.1.0"
  end
end
