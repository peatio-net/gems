require "peatio/tron/version"

module Peatio
  module Tron
    class Error < StandardError; end
    # Your code goes here...
  end
end
