module Irix
  VERSION = "2.6.0"
end
