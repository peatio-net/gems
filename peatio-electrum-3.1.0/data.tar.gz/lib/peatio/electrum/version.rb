# frozen_string_literal: true

module Peatio
  module Electrum
    VERSION = "3.1.0".freeze
  end
end
