# Peatio plugin for Electrum wallet

This gem is a [peatio](https://github.com/openware/peatio) plugin adding the support of Electrum server to manage wallets.

## Installation

Add this line to your application's Gemfile:

```ruby
gem 'peatio-electrum'
```

And then execute:

    $ bundle

Or install it yourself as:

    $ gem install peatio-electrum

