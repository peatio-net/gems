# frozen_string_literal: true

require "custom_name_lib/custom_name_ext"
