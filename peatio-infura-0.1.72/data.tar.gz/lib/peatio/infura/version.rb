module Peatio
  module Infura
    VERSION = '0.1.72'
  end
end
