# Getting Infura in testnet.

You could use one of the next faucet:

* [rinkeby]()
