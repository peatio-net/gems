# Getting Ripple in testnet.

## Faucet

* [developers.ripple.com](https://developers.ripple.com/xrp-test-net-faucet.html)

## Wallet

* [ripplerm.github.io](https://ripplerm.github.io/ripple-wallet/)

## Explorer

* [test.bithomp.com](https://test.bithomp.com/explorer/)